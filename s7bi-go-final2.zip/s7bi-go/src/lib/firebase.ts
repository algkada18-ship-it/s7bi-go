import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAyMTvEL0QdWToK-JK-J6vnk3sNfCjjSLE",
  authDomain: "s7bi-go-ea519.firebaseapp.com",
  projectId: "s7bi-go-ea519",
  storageBucket: "s7bi-go-ea519.firebasestorage.app",
  messagingSenderId: "543906637473",
  appId: "1:543906637473:web:da4f2d8c898788bef7f2e0",
  measurementId: "G-WMFCB551G5"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
