export type UserRole = 'user' | 'worker' | 'shop' | 'admin';
export type SubscriptionType = 'none' | 'yearly' | 'lifetime';
export type PaymentStatus = 'pending' | 'approved' | 'rejected';
export type OrderStatus = 'pending' | 'accepted' | 'delivered' | 'cancelled';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  wilaya: string;
  subscription: SubscriptionType;
  approved: boolean;
  createdAt: any;
}

export interface Shop {
  id: string;
  name: string;
  ownerId: string;
  logoUrl?: string;
  description?: string;
  wilaya: string;
  address?: string;
}

export interface Product {
  id: string;
  shopId: string;
  name: string;
  price: number;
  imageUrl?: string;
  description?: string;
}

export interface Order {
  id: string;
  userId: string;
  shopId: string;
  workerId?: string;
  status: OrderStatus;
  items: any[];
  totalPrice: number;
  deliveryAddress: string;
  deliveryTime?: string;
  createdAt: any;
}

export interface PaymentProof {
  id: string;
  userId: string;
  userRole: UserRole;
  type: SubscriptionType;
  proofImageUrl: string;
  status: PaymentStatus;
  amount: number;
  createdAt: any;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}
