import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot, updateDoc, doc, orderBy } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { Order, OperationType } from '../types';
import { handleFirestoreError } from '../lib/db';
import { Truck, MapPin, Navigation, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function WorkerDashboard() {
  const { user, profile } = useAuth();
  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    // 1. Fetch available orders in worker's wilaya
    // For simplicity, we just filter by status='pending' and later we can add wilaya
    const qAvailable = query(
      collection(db, 'orders'), 
      where('status', '==', 'pending'),
      orderBy('createdAt', 'desc')
    );
    const unsubAvailable = onSnapshot(qAvailable, (snap) => {
      setAvailableOrders(snap.docs.map(d => ({ ...d.data(), id: d.id } as Order)));
      setLoading(false);
    });

    // 2. Fetch orders accepted by this worker
    const qMyOrders = query(
      collection(db, 'orders'), 
      where('workerId', '==', user?.uid),
      where('status', 'in', ['accepted']),
      orderBy('createdAt', 'desc')
    );
    const unsubMy = onSnapshot(qMyOrders, (snap) => {
      setMyOrders(snap.docs.map(d => ({ ...d.data(), id: d.id } as Order)));
    });

    return () => {
      unsubAvailable();
      unsubMy();
    };
  }, [profile, user]);

  const handleAcceptOrder = async (orderId: string) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        workerId: user.uid,
        status: 'accepted',
        deliveryTime: '30-45 mins'
      });
    } catch (err) {
      alert('Failed to accept order. Someone might have taken it.');
    }
  };

  const handleCompleteOrder = async (orderId: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: 'delivered'
      });
    } catch (err) {
      alert('Failed to complete order');
    }
  };

  if (profile?.approved === false) {
    return (
      <div className="max-w-2xl mx-auto mt-20 text-center">
        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white p-16 rounded-4xl shadow-sm border border-slate-200">
           <div className="w-24 h-24 bg-amber-50 text-amber-500 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner">
              <Clock className="w-12 h-12" />
           </div>
           <h2 className="text-4xl font-black text-slate-900 mb-4 uppercase tracking-tighter">Verification Pending</h2>
           <p className="text-slate-500 leading-relaxed mb-10 font-medium">
             Your biological and digital credentials are currently being processed by our team. 
             Once authorized, you will be allowed to intercept and execute delivery missions.
           </p>
           <div className="bg-slate-50 py-5 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest border border-slate-200">
             Estimated clearance time: 2.0 - 6.0 Hours
           </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20 px-2 lg:px-0">
      <header className="flex flex-col md:flex-row justify-between items-end gap-8">
        <div>
          <div className="flex items-center gap-4 mb-4">
             <span className="bg-emerald-600 text-white px-4 py-1 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-emerald-600/20">Active Operator</span>
             <div className="flex items-center gap-2 text-slate-400 border-l border-slate-200 pl-4 font-black text-[10px] uppercase tracking-widest">
               <MapPin className="w-4 h-4 text-emerald-600"/> {profile?.wilaya}
             </div>
          </div>
          <h1 className="text-4xl font-black text-slate-900 uppercase tracking-tighter">Delivery Node</h1>
        </div>
        
        <div className="bg-slate-900 p-2 rounded-2xl shadow-2xl flex gap-1">
          <div className="px-8 py-3 rounded-xl bg-emerald-600 text-white font-black text-xs uppercase tracking-widest flex items-center gap-3">
             <Truck className="w-5 h-5" /> 
             <span>Runner Protocol</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Active Tasks */}
        <section className="space-y-8 px-2">
           <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
              <Navigation className="w-6 h-6 text-emerald-600" /> Active Mission Buffer
           </h2>
           
           <div className="space-y-8">
             {myOrders.length === 0 ? (
               <div className="h-64 bg-white border-2 border-dashed border-slate-200 rounded-4xl flex flex-col items-center justify-center text-slate-400">
                  <Navigation className="w-12 h-12 mb-4 opacity-20" />
                  <p className="font-black text-[10px] uppercase tracking-[0.3em]">No active tasks detected.</p>
               </div>
             ) : (
               myOrders.map(order => (
                 <motion.div 
                   key={order.id} 
                   layoutId={order.id}
                   className="bg-slate-900 text-white rounded-4xl p-10 shadow-2xl relative overflow-hidden group"
                 >
                   <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full -mr-32 -mt-32 blur-3xl opacity-50" />
                   
                   <div className="flex justify-between items-start mb-10">
                      <div>
                        <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Mission Identifier</p>
                        <h3 className="text-3xl font-black tracking-tighter uppercase tabular-nums">#{order.id.slice(0, 8).toUpperCase()}</h3>
                      </div>
                      <div className="h-10 px-4 bg-emerald-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest flex items-center shadow-lg">
                        {order.status}
                      </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                     <div className="p-6 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-sm">
                        <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-3">Payload Origin</p>
                        <p className="text-sm font-bold leading-relaxed">{order.deliveryAddress || 'Sector Terminal Alpha'}</p>
                     </div>
                     <div className="p-6 bg-white/5 rounded-3xl border border-white/10 backdrop-blur-sm">
                        <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-3">Net Realization</p>
                        <p className="text-3xl font-black text-emerald-400 tabular-nums">500 DZD</p>
                     </div>
                   </div>

                   <button 
                     onClick={() => handleCompleteOrder(order.id)}
                     className="w-full h-18 bg-white text-slate-900 rounded-3xl font-black text-sm hover:bg-emerald-500 hover:text-white transition-all shadow-xl shadow-slate-950 flex items-center justify-center gap-3 active:scale-95 uppercase tracking-[0.2em]"
                   >
                     <CheckCircle2 className="w-6 h-6" /> Terminate Mission
                   </button>
                 </motion.div>
               ))
             )}
           </div>
        </section>

        {/* Global Orders Feed */}
        <section className="space-y-8 px-2">
           <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
              <AlertCircle className="text-amber-500 w-6 h-6" /> Signal Intercept Queue
           </h2>
           
           <div className="bg-white rounded-4xl border border-slate-200 p-4 space-y-4 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-full -mr-16 -mt-16 blur-2xl" />
              {availableOrders.length === 0 ? (
                <div className="py-20 text-center text-slate-300 font-black uppercase tracking-[0.3em] text-[10px]">
                   Scanning sector waves...
                </div>
              ) : (
                availableOrders.map(order => (
                  <motion.div 
                    key={order.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="p-8 rounded-3xl bg-slate-50/50 border border-transparent hover:border-slate-200 hover:bg-white transition-all group shadow-sm flex flex-col md:flex-row items-center justify-between gap-6"
                  >
                    <div className="flex items-center gap-6 w-full md:w-auto">
                       <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-inner group-hover:bg-slate-900 group-hover:text-white transition-all duration-500">
                          <Truck className="w-8 h-8" />
                       </div>
                       <div className="flex-1">
                         <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-black text-slate-900 uppercase tracking-tight text-lg">System Relay</h4>
                            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">{order.wilaya}</span>
                         </div>
                         <p className="text-xs font-bold text-slate-400 line-clamp-1 truncate w-48">{order.deliveryAddress || 'Sector Grid Coordinates'}</p>
                       </div>
                    </div>
                    
                    <div className="flex items-center gap-6 w-full md:w-auto pt-6 md:pt-0 border-t md:border-t-0 border-slate-100">
                       <div className="text-right hidden md:block">
                          <p className="text-xl font-black text-emerald-600 tabular-nums leading-none mb-1">{formatCurrency(order.totalPrice || 0)}</p>
                          <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">Aggregate</p>
                       </div>
                       <button 
                        onClick={() => handleAcceptOrder(order.id)}
                        className="flex-1 md:flex-none h-14 px-8 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-600 transition-all shadow-xl shadow-slate-900/10 active:scale-95"
                       >
                         Accept
                       </button>
                    </div>
                  </motion.div>
                ))
              )}
           </div>
        </section>
      </div>
    </div>
  );
}
