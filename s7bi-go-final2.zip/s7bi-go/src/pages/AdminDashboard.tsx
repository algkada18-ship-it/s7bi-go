import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, onSnapshot, doc, updateDoc, orderBy } from 'firebase/firestore';
import { PaymentProof, UserProfile, OperationType } from '../types';
import { handleFirestoreError } from '../lib/db';
import { Check, X, Users, CreditCard, ShieldCheck, Clock } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

function formatDZD(amount: number) {
  return amount.toLocaleString('ar-DZ') + ' دج';
}

const ROLE_AR: Record<string, string> = {
  admin: 'مدير',
  shop: 'متجر',
  worker: 'عامل توصيل',
  user: 'مستخدم',
};

const STATUS_AR: Record<string, string> = {
  pending: 'في الانتظار',
  approved: 'موافق عليه',
  rejected: 'مرفوض',
};

export default function AdminDashboard() {
  const [payments, setPayments] = useState<PaymentProof[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'payments' | 'users'>('payments');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    const qPayments = query(collection(db, 'payments'), orderBy('createdAt', 'desc'));
    const unsubscribePayments = onSnapshot(qPayments, (snapshot) => {
      setPayments(snapshot.docs.map(d => ({ ...d.data(), id: d.id } as PaymentProof)));
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'payments'));

    const qUsers = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubscribeUsers = onSnapshot(qUsers, (snapshot) => {
      setUsers(snapshot.docs.map(d => ({ ...d.data(), id: d.id } as any as UserProfile)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));

    return () => {
      unsubscribePayments();
      unsubscribeUsers();
    };
  }, []);

  const handleAction = async (payment: PaymentProof, action: 'approve' | 'reject') => {
    try {
      await updateDoc(doc(db, 'payments', payment.id), {
        status: action === 'approve' ? 'approved' : 'rejected'
      });

      if (action === 'approve') {
        await updateDoc(doc(db, 'users', payment.userId), {
          subscription: payment.type,
          approved: true
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'payments');
    }
  };

  if (loading) return (
    <div className="p-10 text-center font-black animate-pulse text-slate-400 text-lg" dir="rtl">
      جاري تحميل البيانات...
    </div>
  );

  return (
    <div className="space-y-12 pb-20" dir="rtl">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-2">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tighter mb-2">لوحة الإدارة المركزية</h1>
          <p className="text-slate-500 font-medium">مراقبة وإدارة المستخدمين والاشتراكات</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl p-1 w-fit">
          <span className="text-xs text-slate-400 px-3">
            {payments.filter(p => p.status === 'pending').length} طلب معلّق
          </span>
        </div>
      </header>

      {/* Tabs */}
      <div className="flex bg-slate-900 p-1.5 rounded-2xl shadow-xl w-fit">
        <button
          onClick={() => setActiveTab('payments')}
          className={cn(
            "px-6 py-2.5 rounded-xl font-black text-xs transition-all gap-2 flex items-center",
            activeTab === 'payments' ? "bg-emerald-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          )}
        >
          <CreditCard className="w-4 h-4" />
          طلبات الاشتراك
          {payments.filter(p => p.status === 'pending').length > 0 && (
            <span className="bg-white text-emerald-600 w-5 h-5 rounded-lg flex items-center justify-center font-black text-[10px]">
              {payments.filter(p => p.status === 'pending').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={cn(
            "px-6 py-2.5 rounded-xl font-black text-xs transition-all gap-2 flex items-center",
            activeTab === 'users' ? "bg-emerald-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          )}
        >
          <Users className="w-4 h-4" />
          المستخدمون
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'payments' ? (
          <motion.div
            key="payments"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {payments.length === 0 ? (
              <div className="col-span-full h-80 bg-white rounded-4xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400">
                <CreditCard className="w-16 h-16 mb-4 opacity-20" />
                <p className="font-bold text-lg">لا توجد طلبات حالياً</p>
              </div>
            ) : (
              payments.map(payment => (
                <motion.div
                  key={payment.id}
                  layout
                  className="bg-white rounded-4xl border border-slate-200 shadow-sm overflow-hidden flex flex-col group hover:shadow-2xl hover:shadow-slate-900/5 transition-all duration-500"
                >
                  <div className="h-56 relative overflow-hidden bg-slate-900 cursor-pointer" onClick={() => setSelectedImage(payment.proofImageUrl)}>
                    <img
                      src={payment.proofImageUrl}
                      alt="إيصال الدفع"
                      className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000 mix-blend-luminosity"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="px-6 py-3 bg-white text-slate-900 rounded-full font-black text-xs shadow-2xl">
                        عرض الإيصال
                      </div>
                    </div>
                    <div className="absolute top-4 left-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-black shadow-lg backdrop-blur-md",
                        payment.status === 'pending' ? "bg-amber-500/90 text-white" :
                          payment.status === 'approved' ? "bg-emerald-500/90 text-white" : "bg-red-500/90 text-white"
                      )}>
                        {STATUS_AR[payment.status] || payment.status}
                      </span>
                    </div>
                  </div>

                  <div className="p-8 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <p className="text-slate-400 text-[10px] font-black mb-1">رقم المستخدم</p>
                        <p className="text-slate-900 font-black text-sm">{payment.userId.slice(0, 10)}...</p>
                      </div>
                      <div className="text-left">
                        <p className="text-slate-400 text-[10px] font-black mb-1">المبلغ</p>
                        <p className="text-xl font-black text-emerald-600">{formatDZD(payment.amount)}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-6 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                      <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center text-slate-400">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-slate-400">نوع الاشتراك</p>
                        <p className="text-xs font-bold text-slate-600 mt-0.5">
                          {payment.type === 'yearly' ? 'سنوي - 12,000 دج' : 'مدى الحياة - 32,000 دج'} | {ROLE_AR[payment.userRole] || payment.userRole}
                        </p>
                      </div>
                    </div>

                    {payment.status === 'pending' && (
                      <div className="flex gap-3 mt-auto">
                        <button
                          onClick={() => handleAction(payment, 'approve')}
                          className="flex-1 h-12 bg-slate-900 text-white rounded-2xl font-black text-xs hover:bg-emerald-600 transition-all flex items-center justify-center gap-2 shadow-xl"
                        >
                          <Check className="w-4 h-4" /> قبول
                        </button>
                        <button
                          onClick={() => handleAction(payment, 'reject')}
                          className="w-12 h-12 flex items-center justify-center border-2 border-slate-100 text-slate-300 rounded-2xl hover:border-red-100 hover:text-red-500 hover:bg-red-50 transition-all"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        ) : (
          <motion.div
            key="users"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white rounded-4xl border border-slate-200 overflow-hidden shadow-sm"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/50">
                    <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">المستخدم</th>
                    <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">الدور</th>
                    <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">الولاية</th>
                    <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map(u => (
                    <tr key={u.uid} className="group hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white font-black text-lg shadow-lg">
                            {u.name.charAt(0)}
                          </div>
                          <div>
                            <span className="font-black text-slate-900 text-sm block">{u.name}</span>
                            <span className="text-[10px] text-slate-400 font-bold">{u.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black border",
                          u.role === 'admin' ? "bg-purple-50 text-purple-600 border-purple-100" :
                            u.role === 'shop' ? "bg-emerald-50 text-emerald-600 border-emerald-100" :
                              u.role === 'worker' ? "bg-amber-50 text-amber-600 border-amber-100" : "bg-slate-50 text-slate-400 border-slate-100"
                        )}>
                          {ROLE_AR[u.role] || u.role}
                        </span>
                      </td>
                      <td className="px-8 py-6">
                        <span className="text-xs font-bold text-slate-600">{u.wilaya}</span>
                      </td>
                      <td className="px-8 py-6">
                        {u.approved ? (
                          <div className="flex items-center gap-2 text-emerald-600">
                            <div className="w-5 h-5 bg-emerald-100 rounded-lg flex items-center justify-center">
                              <ShieldCheck className="w-3 h-3" />
                            </div>
                            <span className="text-[10px] font-black">مفعّل</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-amber-500">
                            <div className="w-5 h-5 bg-amber-100 rounded-lg flex items-center justify-center animate-pulse">
                              <Clock className="w-3 h-3" />
                            </div>
                            <span className="text-[10px] font-black">في الانتظار</span>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Image Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-[60] bg-slate-900/95 backdrop-blur-xl flex items-center justify-center p-8 cursor-zoom-out"
          onClick={() => setSelectedImage(null)}
        >
          <motion.img
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            src={selectedImage}
            className="max-w-full max-h-full rounded-4xl shadow-2xl border-4 border-white/10"
          />
          <button className="absolute top-10 left-10 text-white p-4 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-10 h-10" />
          </button>
        </div>
      )}
    </div>
  );
}
