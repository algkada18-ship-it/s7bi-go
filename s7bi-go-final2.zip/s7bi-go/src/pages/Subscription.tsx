import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { CheckCircle2, CreditCard, Clock, Landmark, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { OperationType } from '../types';
import { handleFirestoreError } from '../lib/db';

const ADMIN_WHATSAPP = '213656965019';
const CCP_NUMBER = '00799999004207118835';
const BENEFICIARY = 'S7BI GO ENTERPRISE';

const PLANS = [
  {
    id: 'yearly',
    title: 'اشتراك سنوي',
    price: 12000,
    period: '/ سنة',
    desc: 'وصول كامل لمدة سنة واحدة',
    badge: 'الأكثر شيوعاً',
  },
  {
    id: 'lifetime',
    title: 'اشتراك مدى الحياة',
    price: 32000,
    period: 'مرة واحدة',
    desc: 'وصول غير محدود للأبد',
    badge: 'الأفضل قيمة',
  },
];

function formatDZD(amount: number) {
  return amount.toLocaleString('ar-DZ') + ' دج';
}

export default function Subscription() {
  const { user, profile } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<string>('yearly');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedPlanData = PLANS.find(p => p.id === selectedPlan)!;

  const handleSendWhatsApp = async () => {
    if (!user || !profile) return;
    setLoading(true);
    setError(null);
    try {
      // حفظ الطلب في Firestore
      await addDoc(collection(db, 'payments'), {
        userId: user.uid,
        userRole: profile.role,
        userName: profile.name,
        userEmail: user.email,
        type: selectedPlan,
        amount: selectedPlanData.price,
        status: 'pending',
        method: 'whatsapp',
        createdAt: serverTimestamp(),
      });

      // فتح واتساب برسالة جاهزة
      const message = encodeURIComponent(
        `🚚 *طلب اشتراك s7bi GO*\n\n` +
        `👤 الاسم: ${profile.name}\n` +
        `📧 البريد: ${user.email}\n` +
        `🆔 رقم UID: ${user.uid}\n\n` +
        `📦 نوع الاشتراك: ${selectedPlanData.title}\n` +
        `💰 المبلغ: ${formatDZD(selectedPlanData.price)}\n\n` +
        `📎 مرفق: صورة إيصال الدفع`
      );
      window.open(`https://wa.me/${ADMIN_WHATSAPP}?text=${message}`, '_blank');
      setSubmitted(true);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, 'payments');
      setError('حدث خطأ. حاول مجدداً.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="max-w-xl mx-auto mt-20 text-center" dir="rtl">
        <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white p-16 rounded-3xl shadow-sm border border-slate-200">
          <div className="w-24 h-24 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">تم إرسال الطلب ✅</h2>
          <p className="text-slate-500 mb-6 leading-relaxed">
            تم فتح واتساب. أرسل صورة إيصال الدفع للإدارة وسيتم تفعيل حسابك خلال 12 ساعة.
          </p>
          <div className="flex items-center justify-center gap-3 text-slate-700 bg-slate-50 py-4 rounded-2xl border border-slate-200 font-bold text-sm">
            <Clock className="w-4 h-4 text-emerald-600" />
            الحالة: في انتظار تأكيد الدفع
          </div>
          <button
            onClick={handleSendWhatsApp}
            className="mt-6 w-full h-12 rounded-2xl bg-green-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-all"
          >
            <MessageCircle className="w-5 h-5" />
            إعادة فتح واتساب
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto mt-10" dir="rtl">
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">تفعيل الحساب</h1>
          <p className="text-slate-500">اختر خطة الاشتراك وادفع عبر CCP ثم أرسل الإيصال</p>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PLANS.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlan(plan.id)}
              className={cn(
                "p-8 rounded-3xl border-2 transition-all flex flex-col items-start gap-4 text-right relative overflow-hidden",
                selectedPlan === plan.id
                  ? 'border-emerald-600 bg-white shadow-xl shadow-emerald-500/10'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              )}
            >
              <span className={cn(
                "text-xs font-bold px-3 py-1 rounded-full",
                selectedPlan === plan.id ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-400'
              )}>
                {plan.badge}
              </span>
              <p className="text-xl font-bold text-slate-900">{plan.title}</p>
              <div>
                <span className="text-3xl font-bold text-slate-900">{formatDZD(plan.price)}</span>
                <p className="text-sm text-slate-400 mt-1">{plan.period}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Bank Info */}
        <div className="bg-slate-900 text-white p-8 rounded-3xl">
          <div className="flex items-center gap-3 mb-6">
            <Landmark className="w-6 h-6 text-emerald-400" />
            <h3 className="font-bold text-xl">معلومات الدفع</h3>
          </div>
          <div className="space-y-4">
            <div className="bg-white/5 p-4 rounded-2xl">
              <p className="text-slate-400 text-xs font-bold mb-1">المستفيد</p>
              <p className="text-white font-bold">{BENEFICIARY}</p>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl">
              <p className="text-slate-400 text-xs font-bold mb-1">رقم حساب CCP</p>
              <p className="text-white font-bold text-lg tracking-widest">{CCP_NUMBER}</p>
            </div>
            <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl">
              <p className="text-amber-400 text-xs font-bold mb-1">⚠️ مهم</p>
              <p className="text-slate-300 text-sm">بعد الدفع، اضغط الزر أدناه لإرسال الإيصال عبر واتساب مع رقم UID تلقائياً</p>
            </div>
          </div>
        </div>

        {/* WhatsApp Button */}
        {error && <p className="text-red-600 bg-red-50 p-4 rounded-xl text-sm">{error}</p>}

        <button
          onClick={handleSendWhatsApp}
          disabled={loading}
          className="w-full h-16 rounded-2xl bg-green-600 text-white font-bold text-lg hover:bg-green-700 transition-all shadow-xl shadow-green-600/20 disabled:opacity-50 flex items-center justify-center gap-3"
        >
          {loading ? (
            <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <MessageCircle className="w-6 h-6" />
              دفعت؟ أرسل الإيصال عبر واتساب
            </>
          )}
        </button>

        <p className="text-center text-slate-400 text-sm">
          سيفتح واتساب تلقائياً مع رسالة تحتوي على بياناتك ورقم UID
        </p>
      </div>
    </div>
  );
}
