import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, onSnapshot, orderBy } from 'firebase/firestore';
import { Shop, Product, OperationType } from '../types';
import { handleFirestoreError } from '../lib/db';
import { ShoppingBag, Search, MapPin, Star, Clock, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { useAuth } from '../hooks/useAuth';

export default function Home() {
  const { profile } = useAuth();
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'shops'), orderBy('name', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setShops(snapshot.docs.map(d => ({ ...d.data(), id: d.id } as Shop)));
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'shops'));
    return () => unsubscribe();
  }, []);

  const filteredShops = shops.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.wilaya.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section - Bento Style */}
      <section className="relative h-[450px] rounded-4xl overflow-hidden shadow-2xl border border-white/20">
        <div className="absolute inset-0 bg-slate-900">
          <img 
            src="https://images.unsplash.com/photo-1526367790999-0150786486a9?auto=format&fit=crop&q=80&w=2000" 
            alt="Delivery" 
            className="w-full h-full object-cover opacity-60 mix-blend-luminosity"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
        </div>
        <div className="relative h-full flex flex-col items-center justify-center text-center p-8 text-white">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-emerald-600 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-6 shadow-lg shadow-emerald-600/40"
          >
            Algorithm Powered Delivery
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-8xl font-black mb-6 tracking-tighter leading-none"
          >
            s7bi <span className="text-emerald-500 italic">GO</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg md:text-xl font-medium max-w-xl text-slate-300 mb-10"
          >
            Algerian delivery ecosystem connecting users, stores, and runners.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="w-full max-w-xl relative flex items-center"
          >
            <div className="absolute left-6 text-emerald-500">
              <Search className="w-6 h-6" />
            </div>
            <input 
              type="text"
              placeholder="What are you craving today?"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-18 pl-16 pr-6 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 text-white placeholder-white/40 shadow-2xl focus:outline-none focus:ring-4 focus:ring-emerald-500/20 text-lg font-medium transition-all"
            />
          </motion.div>
        </div>
      </section>

      {/* Categories Bento */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { icon: ShoppingBag, label: 'Fast Food', color: 'bg-white border border-slate-200' },
          { icon: ShoppingBag, label: 'Groceries', color: 'bg-white border border-slate-200' },
          { icon: ShoppingBag, label: 'Electronics', color: 'bg-white border border-slate-200' },
          { icon: ShoppingBag, label: 'Pharmacy', color: 'bg-emerald-600 text-white shadow-xl shadow-emerald-600/20' },
        ].map((cat, i) => (
          <button key={i} className={cn("p-8 rounded-4xl flex flex-col items-center gap-4 transition-all hover:translate-y-[-4px] active:scale-95 cursor-pointer", cat.color)}>
            <div className={cn("p-4 rounded-2xl", cat.label === 'Pharmacy' ? 'bg-white/20 text-white' : 'bg-slate-50 text-emerald-600')}>
              <cat.icon className="w-8 h-8" />
            </div>
            <span className="font-bold text-lg tracking-tight uppercase">{cat.label}</span>
          </button>
        ))}
      </section>

      {/* Shop Grid Bento */}
      <section>
        <div className="flex items-end justify-between mb-10 px-2">
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase mb-2">Top Rated Partners</h2>
            <p className="text-slate-500 font-medium tracking-wide">Verified shops with high performance scores</p>
          </div>
          <button className="px-6 py-2 bg-slate-900 text-white rounded-full text-xs font-black uppercase tracking-widest hover:bg-emerald-600 transition-colors">
            Discover More
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-80 bg-white border border-slate-200 rounded-4xl animate-pulse" />
            ))}
          </div>
        ) : filteredShops.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-4xl border-2 border-dashed border-slate-200">
             <ShoppingBag className="w-16 h-16 text-slate-200 mx-auto mb-6" />
             <h3 className="text-2xl font-bold text-slate-400">System scanning... no matches found.</h3>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredShops.map((shop) => (
              <motion.div 
                key={shop.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white rounded-4xl overflow-hidden shadow-sm border border-slate-200 group cursor-pointer hover:shadow-2xl hover:shadow-slate-900/5 transition-all duration-500 flex flex-col"
              >
                <div className="h-56 relative overflow-hidden">
                   <img 
                      src={shop.logoUrl || `https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&q=80&w=800`} 
                      alt={shop.name} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:rotate-1"
                   />
                   <div className="absolute top-6 left-6 bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-2xl text-[10px] font-black text-white uppercase tracking-widest shadow-lg">
                      {shop.wilaya}
                   </div>
                </div>
                <div className="p-8 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors uppercase leading-tight">{shop.name}</h3>
                    <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
                       <Star className="w-4 h-4 fill-emerald-600" />
                       <span>4.9</span>
                    </div>
                  </div>
                  <p className="text-slate-500 text-sm mb-8 line-clamp-2 leading-relaxed font-medium">{shop.description || 'Verified local shop offering premium products and high-speed delivery service across the region.'}</p>
                  
                  <div className="mt-auto flex items-center justify-between pt-6 border-t border-slate-100">
                    <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                          <Clock className="w-4 h-4 text-emerald-600" />
                       </div>
                       <span className="text-[10px] font-black text-slate-500 uppercase">25 MIN</span>
                    </div>
                    <button className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-all">
                       <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
