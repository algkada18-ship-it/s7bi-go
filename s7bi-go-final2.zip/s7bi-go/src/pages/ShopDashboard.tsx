import React, { useState, useEffect } from 'react';
import { db, storage } from '../lib/firebase';
import { collection, query, where, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, getDocs } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useAuth } from '../hooks/useAuth';
import { Order, Product, Shop, OperationType } from '../types';
import { handleFirestoreError } from '../lib/db';
import { Package, Plus, ShoppingBag, Clock, CheckCircle2, MapPin, Upload, X } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function ShopDashboard() {
  const { user, profile } = useAuth();
  const [shop, setShop] = useState<Shop | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddMode, setIsAddMode] = useState(false);
  
  const [newProduct, setNewProduct] = useState({ name: '', price: '', description: '' });
  const [productFile, setProductFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!user) return;
    const qShop = query(collection(db, 'shops'), where('ownerId', '==', user.uid));
    const unsubShop = onSnapshot(qShop, (snap) => {
      if (!snap.empty) setShop({ ...snap.docs[0].data(), id: snap.docs[0].id } as Shop);
    });
    return () => unsubShop();
  }, [user]);

  useEffect(() => {
    if (!shop) return;
    const qOrders = query(collection(db, 'orders'), where('shopId', '==', shop.id));
    const unsubOrders = onSnapshot(qOrders, (snap) => {
      setOrders(snap.docs.map(d => ({ ...d.data(), id: d.id } as Order)));
      setLoading(false);
    });

    const qProducts = query(collection(db, 'shops', shop.id, 'products'));
    const unsubProducts = onSnapshot(qProducts, (snap) => {
      setProducts(snap.docs.map(d => ({ ...d.data(), id: d.id } as Product)));
    });

    return () => {
      unsubOrders();
      unsubProducts();
    };
  }, [shop]);

  const handleCreateShop = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    const shopName = prompt('Enter your shop name:');
    if (!shopName) return;
    try {
      await addDoc(collection(db, 'shops'), {
        name: shopName,
        ownerId: user.uid,
        wilaya: profile.wilaya,
        description: 'Quality local store',
        createdAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'shops');
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shop || !productFile) return;
    setUploading(true);
    try {
      const storageRef = ref(storage, `shops/${shop.id}/products/${Date.now()}_${productFile.name}`);
      await uploadBytes(storageRef, productFile);
      const imageUrl = await getDownloadURL(storageRef);
      await addDoc(collection(db, 'shops', shop.id, 'products'), {
        name: newProduct.name,
        price: Number(newProduct.price),
        description: newProduct.description,
        imageUrl,
        shopId: shop.id,
      });
      setNewProduct({ name: '', price: '', description: '' });
      setProductFile(null);
      setIsAddMode(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setUploading(false);
    }
  };

  if (!shop) {
    return (
      <div className="max-w-2xl mx-auto mt-20 text-center">
        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white p-16 rounded-4xl shadow-sm border border-slate-200">
           <div className="w-24 h-24 bg-slate-900 flex items-center justify-center rounded-3xl mx-auto mb-8 shadow-2xl text-emerald-400">
             <ShoppingBag className="w-12 h-12" />
           </div>
           <h2 className="text-4xl font-black text-slate-900 mb-4 uppercase tracking-tighter">Shop Initialization</h2>
           <p className="text-slate-500 mb-12 leading-relaxed font-medium">You haven't established a store footprint in our grid. Deploy your commerce module to begin receiving orders.</p>
           <button 
             onClick={handleCreateShop} 
             className="w-full h-18 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-[0.2em] shadow-xl shadow-emerald-500/20 hover:bg-slate-900 transition-all"
           >
              Establish Commerce Point
           </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8 px-2">
        <div className="flex-1">
          <h1 className="text-4xl font-black text-slate-900 mb-2 uppercase tracking-tighter">{shop.name} Hub</h1>
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-2 text-emerald-600">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-widest leading-none">Operational</span>
             </div>
             <div className="flex items-center gap-2 text-slate-400 border-l border-slate-200 pl-6">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold uppercase tracking-tight">{shop.wilaya} Sector</span>
             </div>
          </div>
        </div>
        <button 
          onClick={() => setIsAddMode(true)} 
          className="h-14 px-8 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-900/10 hover:bg-emerald-600 transition-all flex items-center gap-3"
        >
          <Plus className="w-5 h-5" /> Append Product
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Products Grid */}
        <div className="lg:col-span-2 space-y-8">
           <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3 px-2">
             <Package className="w-6 h-6 text-emerald-600" /> 
             Inventory Log ({products.length})
           </h2>
           
           {products.length === 0 ? (
             <div className="h-64 bg-white border-2 border-dashed border-slate-200 rounded-4xl flex flex-col items-center justify-center text-slate-400">
                <Package className="w-12 h-12 mb-4 opacity-20" />
                <p className="font-bold">Inventory buffer empty.</p>
             </div>
           ) : (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {products.map(p => (
                 <motion.div 
                   key={p.id} 
                   layout
                   className="bg-white rounded-4xl border border-slate-200 p-4 shadow-sm group hover:shadow-2xl hover:shadow-slate-900/5 transition-all duration-500 flex gap-6"
                 >
                    <div className="w-32 h-32 rounded-3xl overflow-hidden flex-shrink-0 bg-slate-900">
                       <img 
                          src={p.imageUrl || 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&q=80&w=400'} 
                          className="w-full h-full object-cover opacity-80 mix-blend-luminosity group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" 
                          alt={p.name}
                        />
                    </div>
                    <div className="flex flex-col justify-center flex-1 pr-4">
                       <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight group-hover:text-emerald-600 transition-colors leading-tight mb-1">{p.name}</h4>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight mb-4">{p.description}</p>
                       <p className="text-2xl font-black text-slate-900 tabular-nums">{formatCurrency(p.price)}</p>
                    </div>
                 </motion.div>
               ))}
             </div>
           )}
        </div>

        {/* Orders Stream */}
        <div className="space-y-8">
           <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3 px-2">
             <Clock className="w-6 h-6 text-emerald-600" />
             Request Queue
           </h2>
           
           <div className="bg-white rounded-4xl border border-slate-200 p-6 space-y-4 shadow-sm">
             {orders.length === 0 ? (
               <div className="py-12 text-center text-slate-400 font-black text-[10px] uppercase tracking-widest">
                  Signal stable. No incoming requests.
               </div>
             ) : (
               orders.map(order => (
                 <div key={order.id} className="p-6 rounded-3xl bg-slate-50/50 border border-transparent hover:border-slate-200 hover:bg-white transition-all group">
                   <div className="flex justify-between items-center mb-6">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest",
                        order.status === 'pending' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'
                      )}>
                        {order.status}
                      </span>
                      <span className="text-lg font-black text-slate-900">{formatCurrency(order.totalPrice || 0)}</span>
                   </div>
                   <div className="space-y-2 mb-6">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Payload</p>
                      <p className="text-xs font-bold text-slate-600">{order.items?.length || 0} Unified Products</p>
                   </div>
                   <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                     <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-xl bg-slate-900 flex items-center justify-center text-white font-black text-[10px]">
                         {order.userId.charAt(0).toUpperCase()}
                       </div>
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">UID: {order.userId.slice(0, 8)}</span>
                     </div>
                     {order.workerId ? (
                       <div className="flex items-center gap-1 text-emerald-600">
                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                         <span className="text-[10px] font-black uppercase tracking-widest">In Transit</span>
                       </div>
                     ) : (
                       <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Wait Runner</span>
                     )}
                   </div>
                 </div>
               ))
             )}
           </div>
        </div>
      </div>

      {/* Add Product Interface */}
      <AnimatePresence>
        {isAddMode && (
          <div className="fixed inset-0 z-[70] bg-slate-900/90 backdrop-blur-xl flex items-center justify-center p-6">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-xl rounded-4xl p-12 overflow-hidden shadow-2xl relative"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/5 rounded-full -mr-32 -mt-32 blur-3xl" />
              <div className="flex justify-between items-start mb-12">
                 <div>
                   <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tighter">Data Append</h2>
                   <p className="text-slate-500 font-medium tracking-tight">Configure new inventory parameters</p>
                 </div>
                 <button onClick={() => setIsAddMode(false)} className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-100 transition-colors">
                    <X className="w-6 h-6" />
                 </button>
              </div>
              
              <form onSubmit={handleAddProduct} className="space-y-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Asset Label</label>
                  <input 
                    required
                    type="text" 
                    value={newProduct.name}
                    onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                    placeholder="e.g. Industrial Hub Component" 
                    className="w-full h-16 px-6 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Magnitude (DZD)</label>
                    <input 
                      required
                      type="number" 
                      value={newProduct.price}
                      onChange={e => setNewProduct({...newProduct, price: e.target.value})}
                      placeholder="850.00" 
                      className="w-full h-16 px-6 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-black font-mono"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Visual Protocol</label>
                    <div className={cn(
                      "relative border-2 border-dashed h-16 rounded-2xl transition-all flex items-center justify-center gap-3 px-4",
                      productFile ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    )}>
                      <input 
                        type="file" 
                        onChange={e => setProductFile(e.target.files?.[0] || null)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                      />
                      <Upload className={cn("w-5 h-5", productFile ? 'text-emerald-600' : 'text-slate-300')} />
                      <span className="text-[10px] font-bold text-slate-400 tracking-tight truncate max-w-[120px]">{productFile ? productFile.name : 'Binary Upload'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Logic Specs</label>
                  <textarea 
                    rows={3}
                    value={newProduct.description}
                    onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                    placeholder="Enter detailed technical description and functional specifications..."
                    className="w-full p-6 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-medium py-4"
                  />
                </div>

                <button 
                  disabled={uploading}
                  className="w-full h-18 bg-slate-900 text-white rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-slate-900/20 hover:bg-emerald-600 transition-all disabled:opacity-50 mt-4"
                >
                  {uploading ? 'PROCESSING...' : 'Infect Catalog'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
