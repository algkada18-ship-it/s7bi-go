import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { UserRole } from '../types';
import { handleFirestoreError } from '../lib/db';
import { OperationType } from '../types';
import { Building2, User, Truck, Check } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const ALGERIAN_WILAYAS = [
  { code: '01', name: 'أدرار', latin: 'Adrar' },
  { code: '02', name: 'الشلف', latin: 'Chlef' },
  { code: '03', name: 'الأغواط', latin: 'Laghouat' },
  { code: '04', name: 'أم البواقي', latin: 'Oum El Bouaghi' },
  { code: '05', name: 'باتنة', latin: 'Batna' },
  { code: '06', name: 'بجاية', latin: 'Béjaïa' },
  { code: '07', name: 'بسكرة', latin: 'Biskra' },
  { code: '08', name: 'بشار', latin: 'Béchar' },
  { code: '09', name: 'البليدة', latin: 'Blida' },
  { code: '10', name: 'البويرة', latin: 'Bouira' },
  { code: '11', name: 'تمنراست', latin: 'Tamanrasset' },
  { code: '12', name: 'تبسة', latin: 'Tébessa' },
  { code: '13', name: 'تلمسان', latin: 'Tlemcen' },
  { code: '14', name: 'تيارت', latin: 'Tiaret' },
  { code: '15', name: 'تيزي وزو', latin: 'Tizi Ouzou' },
  { code: '16', name: 'الجزائر العاصمة', latin: 'Alger' },
  { code: '17', name: 'الجلفة', latin: 'Djelfa' },
  { code: '18', name: 'جيجل', latin: 'Jijel' },
  { code: '19', name: 'سطيف', latin: 'Sétif' },
  { code: '20', name: 'سعيدة', latin: 'Saïda' },
  { code: '21', name: 'سكيكدة', latin: 'Skikda' },
  { code: '22', name: 'سيدي بلعباس', latin: 'Sidi Bel Abbès' },
  { code: '23', name: 'عنابة', latin: 'Annaba' },
  { code: '24', name: 'قالمة', latin: 'Guelma' },
  { code: '25', name: 'قسنطينة', latin: 'Constantine' },
  { code: '26', name: 'المدية', latin: 'Médéa' },
  { code: '27', name: 'مستغانم', latin: 'Mostaganem' },
  { code: '28', name: 'المسيلة', latin: "M'Sila" },
  { code: '29', name: 'معسكر', latin: 'Mascara' },
  { code: '30', name: 'ورقلة', latin: 'Ouargla' },
  { code: '31', name: 'وهران', latin: 'Oran' },
  { code: '32', name: 'البيض', latin: 'El Bayadh' },
  { code: '33', name: 'إليزي', latin: 'Illizi' },
  { code: '34', name: 'برج بوعريريج', latin: 'Bordj Bou Arreridj' },
  { code: '35', name: 'بومرداس', latin: 'Boumerdès' },
  { code: '36', name: 'الطارف', latin: 'El Tarf' },
  { code: '37', name: 'تندوف', latin: 'Tindouf' },
  { code: '38', name: 'تيسمسيلت', latin: 'Tissemsilt' },
  { code: '39', name: 'الوادي', latin: 'El Oued' },
  { code: '40', name: 'خنشلة', latin: 'Khenchela' },
  { code: '41', name: 'سوق أهراس', latin: 'Souk Ahras' },
  { code: '42', name: 'تيبازة', latin: 'Tipaza' },
  { code: '43', name: 'ميلة', latin: 'Mila' },
  { code: '44', name: 'عين الدفلى', latin: 'Aïn Defla' },
  { code: '45', name: 'النعامة', latin: 'Naâma' },
  { code: '46', name: 'عين تموشنت', latin: 'Aïn Témouchent' },
  { code: '47', name: 'غرداية', latin: 'Ghardaïa' },
  { code: '48', name: 'غليزان', latin: 'Relizane' },
  { code: '49', name: 'المغير', latin: "El M'Ghair" },
  { code: '50', name: 'المنيعة', latin: 'El Meniaa' },
  { code: '51', name: 'أولاد جلال', latin: 'Ouled Djellal' },
  { code: '52', name: 'برج باجي مختار', latin: 'Bordj Baji Mokhtar' },
  { code: '53', name: 'بني عباس', latin: 'Béni Abbès' },
  { code: '54', name: 'عين صالح', latin: 'In Salah' },
  { code: '55', name: 'عين قزام', latin: 'In Guezzam' },
  { code: '56', name: 'تقرت', latin: 'Touggourt' },
  { code: '57', name: 'جانت', latin: 'Djanet' },
  { code: '58', name: 'تيميمون', latin: 'Timimoun' },
];

export default function Register() {
  const [user, setUser] = useState(auth.currentUser);
  const [role, setRole] = useState<UserRole>('user');
  const [wilaya, setWilaya] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) setName(u.displayName || '');
    });
  }, []);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      try {
        const provider = new GoogleAuthProvider();
        const result = await signInWithPopup(auth, provider);
        setUser(result.user);
        setName(result.user.displayName || '');
        return;
      } catch (err: any) {
        setError(err.message);
        return;
      }
    }

    if (!wilaya || !name) {
      setError('يرجى ملء جميع الحقول');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const profile = {
        uid: user.uid,
        name,
        email: user.email,
        role,
        wilaya,
        subscription: 'none',
        approved: false,
        createdAt: serverTimestamp(),
      };
      await setDoc(doc(db, 'users', user.uid), profile);
      if (role === 'user') navigate('/');
      else navigate('/subscription');
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-10" dir="rtl">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">إنشاء حساب</h1>
        <p className="text-gray-500 mb-8">انضم إلى أكبر شبكة توصيل في الجزائر</p>

        <form onSubmit={handleRegister} className="space-y-8">
          <div>
            <label className="text-sm font-semibold text-gray-700 mb-4 block">من أنت؟</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { id: 'user', title: 'مستخدم', desc: 'أريد الطلب', icon: User },
                { id: 'worker', title: 'عامل توصيل', desc: 'أريد التوصيل', icon: Truck },
                { id: 'shop', title: 'متجر', desc: 'أريد البيع', icon: Building2 },
              ].map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setRole(r.id as UserRole)}
                  className={cn(
                    "relative flex flex-col items-center p-6 rounded-2xl border-2 transition-all text-center",
                    role === r.id
                      ? "border-emerald-600 bg-emerald-50/50 shadow-sm"
                      : "border-gray-100 bg-white hover:border-gray-200"
                  )}
                >
                  {role === r.id && (
                    <div className="absolute top-2 left-2 w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}
                  <r.icon className={cn("w-8 h-8 mb-3", role === r.id ? "text-emerald-600" : "text-gray-400")} />
                  <span className={cn("font-bold", role === r.id ? "text-emerald-900" : "text-gray-700")}>{r.title}</span>
                  <span className="text-xs text-gray-500 mt-1">{r.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-sm font-semibold text-gray-700">الاسم الكامل</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="محمد أمين"
                className="w-full h-12 px-4 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                dir="rtl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-semibold text-gray-700">الولاية</label>
              <select
                value={wilaya}
                onChange={(e) => setWilaya(e.target.value)}
                className="w-full h-12 px-4 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-white"
                dir="rtl"
              >
                <option value="">اختر الولاية</option>
                {ALGERIAN_WILAYAS.map(w => (
                  <option key={w.code} value={w.latin}>{w.code} - {w.name}</option>
                ))}
              </select>
            </div>
          </div>

          {!user && (
            <p className="text-sm text-amber-600 bg-amber-50 p-4 rounded-xl border border-amber-100">
              سيُطلب منك تسجيل الدخول بحساب Google لإتمام التسجيل.
            </p>
          )}

          {error && (
            <p className="text-sm text-red-600 bg-red-50 p-4 rounded-xl border border-red-100">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full h-14 rounded-2xl bg-emerald-600 text-white font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 disabled:opacity-50"
          >
            {loading ? 'جاري المعالجة...' : user ? 'إتمام التسجيل' : 'التسجيل بحساب Google'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
