import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Truck } from 'lucide-react';
import { motion } from 'motion/react';

export default function Login() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);

      const profileRef = doc(db, 'users', result.user.uid);
      const docSnap = await getDoc(profileRef);

      if (!docSnap.exists()) {
        // تعيين أدمن تلقائي إذا كان البريد الإلكتروني للمطور
        const isAdminEmail = result.user.email === 'algkada18@gmail.com';
        if (isAdminEmail) {
          await setDoc(profileRef, {
            uid: result.user.uid,
            name: result.user.displayName || 'Admin',
            email: result.user.email,
            role: 'admin',
            wilaya: 'Alger',
            subscription: 'lifetime',
            approved: true,
            createdAt: serverTimestamp(),
          });
          navigate('/admin');
        } else {
          navigate('/register');
        }
      } else {
        const data = docSnap.data();
        if (data?.role === 'admin') navigate('/admin');
        else navigate('/');
      }
    } catch (err: any) {
      setError('فشل تسجيل الدخول. تأكد من اتصالك بالإنترنت.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20" dir="rtl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100"
      >
        <div className="flex flex-col items-center gap-4 mb-8">
          <div className="p-3 bg-emerald-100 rounded-xl text-emerald-600">
            <Truck className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">مرحباً بك</h1>
          <p className="text-gray-500 text-center">سجّل الدخول إلى s7bi GO للطلب أو التوصيل</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm text-center">
            {error}
          </div>
        )}

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 bg-white border border-gray-300 py-3 rounded-xl hover:bg-gray-50 transition-colors font-medium text-gray-700 h-12 disabled:opacity-50"
        >
          <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
          {loading ? 'جاري التحقق...' : 'الدخول بحساب Google'}
        </button>

        <p className="mt-8 text-center text-gray-500 text-sm">
          ليس لديك حساب؟{' '}
          <Link to="/register" className="text-emerald-600 font-medium hover:underline">
            سجّل كمتجر أو عامل توصيل
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
