import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Subscription from './pages/Subscription';
import AdminDashboard from './pages/AdminDashboard';
import ShopDashboard from './pages/ShopDashboard';
import WorkerDashboard from './pages/WorkerDashboard';
import { LogOut, CreditCard, Truck } from 'lucide-react';
import { auth } from './lib/firebase';
import { motion, AnimatePresence } from 'motion/react';

function Navbar() {
  const { user, profile, isAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/login');
  };

  return (
    <nav className="fixed top-6 left-1/2 -translate-x-1/2 w-[95%] max-w-7xl h-20 bg-white/80 backdrop-blur-2xl border border-slate-200/50 rounded-4xl flex items-center justify-between px-10 z-[100] shadow-2xl shadow-slate-900/5" dir="rtl">
      <Link to="/" className="flex items-center gap-3 font-black text-2xl tracking-tighter text-slate-900 group">
        <div className="w-10 h-10 bg-slate-900 rounded-2xl flex items-center justify-center text-emerald-400 group-hover:rotate-12 transition-transform duration-500">
          <Truck className="w-6 h-6" />
        </div>
        <span className="uppercase">s7bi <span className="text-emerald-500">GO</span></span>
      </Link>

      <div className="flex items-center gap-6">
        <div className="hidden lg:flex items-center gap-6">
          <Link to="/" className="text-xs font-bold text-slate-400 hover:text-slate-900 transition-colors">الرئيسية</Link>
          {user && (
            <>
              {isAdmin ? (
                <Link to="/admin" className="text-xs font-bold text-slate-400 hover:text-slate-900 transition-colors">لوحة الإدارة</Link>
              ) : (
                <>
                  {profile?.role === 'shop' && <Link to="/shop" className="text-xs font-bold text-slate-400 hover:text-slate-900 transition-colors">المتجر</Link>}
                  {profile?.role === 'worker' && <Link to="/worker" className="text-xs font-bold text-slate-400 hover:text-slate-900 transition-colors">لوحة التوصيل</Link>}
                </>
              )}
            </>
          )}
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              {(profile?.role === 'worker' || profile?.role === 'shop') && profile?.subscription === 'none' && (
                <Link to="/subscription" className="h-10 px-6 bg-amber-100 text-amber-700 rounded-2xl text-xs font-black hover:bg-amber-200 transition-colors flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  اشترك الآن
                </Link>
              )}

              <div className="flex items-center gap-3 bg-slate-50 p-1 rounded-2xl border border-slate-100">
                <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center text-white font-black text-xs">
                  {profile?.name?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase()}
                </div>
                <button onClick={handleLogout} className="p-2 text-slate-400 hover:text-slate-900 transition-colors cursor-pointer">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <Link to="/login" className="h-12 px-8 bg-slate-900 text-white rounded-2xl font-black text-xs hover:bg-emerald-600 transition-all shadow-xl shadow-slate-900/10 flex items-center">
              دخول
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}

function PrivateRoute({ children, role }: { children: React.ReactNode, role?: string }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-slate-200 border-t-emerald-500 rounded-full animate-spin" />
          <span className="text-xs font-black text-slate-400">جاري التحقق من الهوية...</span>
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" />;

  if (role && profile?.role !== role && profile?.role !== 'admin') {
    return <Navigate to="/" />;
  }

  if ((profile?.role === 'worker' || profile?.role === 'shop') && profile?.subscription === 'none' && window.location.pathname !== '/subscription') {
    return <Navigate to="/subscription" />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-slate-50 font-sans selection:bg-emerald-500/30">
          <Navbar />
          <main className="container mx-auto px-6 pt-40 pb-20 max-w-7xl">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />

                <Route path="/subscription" element={
                  <PrivateRoute>
                    <Subscription />
                  </PrivateRoute>
                } />

                <Route path="/admin" element={
                  <PrivateRoute role="admin">
                    <AdminDashboard />
                  </PrivateRoute>
                } />

                <Route path="/shop" element={
                  <PrivateRoute role="shop">
                    <ShopDashboard />
                  </PrivateRoute>
                } />

                <Route path="/worker" element={
                  <PrivateRoute role="worker">
                    <WorkerDashboard />
                  </PrivateRoute>
                } />

                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </AnimatePresence>
          </main>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
